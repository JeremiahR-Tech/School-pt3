import sys

if __name__ == '__main__':

	argu_len = len(sys.argv)

	# Enter ERROR-CHECK (ARGUMENT) or PROGRAM
	if argu_len < 2:
		print("[ERROR] FORMAT: python bnet.py <training_data>")
	else:
		# Intializing variables
		training_file = 0 # Will be used to open file destination of training (string)
		training_data = 0 # All data from training file after opening
		jpds = [] # This is all the training data broken down into sets per line

		for i, arg in enumerate( sys.argv ):
			print(f"[DEBUG] Argument {i: > 2}: {arg}")
			print("")

			# Setting variables using user arguments
			if i == 0:
				pass
			elif i == 1:
				training_file = arg

		# Opening up new lines & collecting data
		with open( training_file ) as f:
			training_data = f.read()

		# Storing training data
		lines = training_data.splitlines()

		for line in lines:
		    if line == 'EOF':
		        break
		    booleans=line.split()
		    jpd_set = []
		    for boolean in booleans:
		    	jpd_set.append( int(boolean) )
		    jpds.append( jpd_set )

		# Debug printing file
		for index, jpd_set in enumerate(jpds):
			print("[DEBUG] File sets")
			print()
			print(f"{index}: {jpd_set}")
