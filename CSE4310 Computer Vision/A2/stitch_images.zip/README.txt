Name: Jeremiah Richard
ID: 1001475742
Course: CSE4310 (Computer Vision)
Instructor: Alex Dillhoff
Program: stitch_images.py
Language: Python 3.10.2

Compiles with python "stitch_images.py"
and take advantage of the "Rainer01.png"
and "Rainer02.png"

- Currently the only code done is for the Keypoint matching