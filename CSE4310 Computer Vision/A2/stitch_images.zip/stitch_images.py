"""
Name: Jeremiah Richard
ID: 1001475742
Course: CSE4310 (Computer Vision)
Instructor: Alex Dillhoff
Program: stitch_images.py

"""

import matplotlib.pyplot as plt
import scipy.ndimage as ndi
import numpy as np
import PIL.Image as Image
from skimage import io
from skimage.transform import AffineTransform
from skimage.transform import resize, ProjectiveTransform, SimilarityTransform, warp
from skimage.measure import ransac
from skimage.color import rgb2gray, rgba2rgb
from skimage.feature import match_descriptors, plot_matches, SIFT
from skimage import measure

def keypointMatching(img1, img2):

	# Extract keypoints from image using SIFT
	img1_gray = rgb2gray(img1)
	sift = SIFT()
	sift.detect_and_extract(img1_gray)
	keypoints1 = sift.keypoints
	descriptors1 = sift.descriptors

	# DEBUG ------
	#print(f'Keypoints: \n {keypoints1}')
	#print(f'descriptors: \n {descriptors1}')

	# Extract keypoints from image using SIFT
	img2_gray = rgb2gray(img2)
	sift.detect_and_extract(img2_gray)
#	keypoints2 = sift.keypoints
	descriptors2 = sift.descriptors

	# Match descriptors between img1 and img2
	matches12 = match_descriptors(descriptors1, descriptors2, cross_check=True, max_ratio=0.8)

	return matches12

def plot_match(matches12, img1, img2):
	img1_gray = rgb2gray(img1)
	sift = SIFT()
	sift.detect_and_extract(img1_gray)
	keypoints1 = sift.keypoints

	img2_gray = rgb2gray(img2)
	sift.detect_and_extract(img2_gray)
	keypoints2 = sift.keypoints

	# Display matches
	fig, ax = plt.subplots()
	plot_matches(ax, img1, img2, keypoints1, keypoints2, matches12)
	ax.axis('off')
	plt.show()

def compute_affine_transform(keypoint1, keypoints2, matches12):
	"""
	The purpose of this code is to take a set of
	points from the source image and match their points
	to a destination image. Then compute an affine transformation
	matrix using normal equations.
	"""

	dst = keypoints1[ matches[:,0] ]
	src = keypoints2[ matches[:,1] ]


#	return affine_transform


# def compute_projective_transform():


def main():
	img1 = "campus_000.jpg"
	img2 = "campus_001.jpg"
	img1 = io.imread(img1)[:,:,:3]
	img2 = io.imread(img2)[:,:,:3]
	matches12 = keypointMatching(img1,img2)
	plot_match(matches12, img1, img2)

	# Image Stitching
	# Estimate Affine Matrix



if __name__ == "__main__":
	main()
