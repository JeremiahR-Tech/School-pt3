// Dalio, Brian A.
// dalioba
// 2022-08-22
//----------------------------------------------------------------
#include <stdio.h>

//----------------------------------------------------------------
int main()
{
  // Oh, boy!
  printf( "Hello, world!  My C development environment WORKS!\n" );

  // No problems detected, so exit with status code 0 for SUCCESS.
  return 0;
}

//----------------------------------------------------------------
